# Shared package for BigTime application

__VERSION__ = "2.1.1"
__API_VERSION__ = "1.1"
